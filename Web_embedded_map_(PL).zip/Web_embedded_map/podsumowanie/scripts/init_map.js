document.addEventListener('DOMContentLoaded', function () {
    var OpenTopoMap = L.tileLayer('https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png', {
        maxZoom: 17,
        attribution: 'Map data: &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors, <a href="http://viewfinderpanoramas.org">SRTM</a> | Map style: &copy; <a href="https://opentopomap.org">OpenTopoMap</a> (<a href="https://creativecommons.org/licenses/by-sa/3.0/">CC-BY-SA</a>)'
    });

    var OpenStreetMap = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors',
        maxZoom: 15,
        minZoom: 2
    });

    var map = L.map('mapid', {
        center: [56.505, 14.5],
        zoom: 3,
        layers: [OpenStreetMap]
    });

    var baseMaps = {
        "OpenStreetMap": OpenStreetMap,
        "OpenTopoMap": OpenTopoMap
    };

    var coordinateDisplayControl = L.Control.extend({
        options: {
            position: 'bottomleft'
        },
        onAdd: function (map) {
            var coordDiv = L.DomUtil.create('div', 'coordinate-display');
            coordDiv.innerHTML = "Y: , X: ";
            return coordDiv;
        }
    });

    var coordinateDisplay = new coordinateDisplayControl();
    coordinateDisplay.addTo(map);

    map.on('mousemove', function (e) {
        var coordDiv = document.querySelector('.coordinate-display');
        coordDiv.innerHTML = "Y: " + e.latlng.lat.toFixed(5) + ", X: " + e.latlng.lng.toFixed(5);
    });

    var legendControl = L.Control.extend({
        options: {
            position: 'topright'
        },
        onAdd: function (map) {
            var legendDiv = L.DomUtil.create('div', 'legend');
            legendDiv.innerHTML = `
                <h3>Legenda</h3>
                <div class="legend-elem">
                    <input type="checkbox" id="toggleLNG" checked>
                    <label for="toggleLNG"><span class="lng-marker"></span><span>Terminale LNG</span></label>
                </div>
                <div class="legend-elem">
                    <input type="checkbox" id="toggleCoal" checked>
                    <label for="toggleCoal"><span class="coal-marker"></span><span>Terminale węglowe</span></label>
                </div>
                <div class="legend-elem">
                    <input type="checkbox" id="togglePowerplants" checked>
                    <label for="togglePowerplants"><span class="powerplant-marker"></span><span>Elektrownie</span></label>
                </div>`;
            return legendDiv;
        }
    });

    map.addControl(new legendControl());
    L.control.layers(baseMaps).addTo(map);

    lngLayer.addTo(map);
    coalLayer.addTo(map);
    powerplantLayer.addTo(map);

    document.getElementById('toggleLNG').addEventListener('change', function () {
        updateLayers();
    });

    document.getElementById('toggleCoal').addEventListener('change', function () {
        updateLayers();
    });

    document.getElementById('togglePowerplants').addEventListener('change', function () {
        updateLayers();
    });

    function updateLayers() {
        clearLayers();

        if (document.getElementById('toggleLNG').checked) {
            lngLayer.addTo(map);
        }

        if (document.getElementById('toggleCoal').checked) {
            coalLayer.addTo(map);
        }

        if (document.getElementById('togglePowerplants').checked) {
            powerplantLayer.addTo(map);
        }

        var selectedCountry = document.getElementById('countryFilter').value;
        if (selectedCountry !== "-1") {
            filterByCountry(selectedCountry);
        }
    }

    populateCountryFilter();
    clearLayers();
    clearInfoDisplay();
    updateLayers();
});