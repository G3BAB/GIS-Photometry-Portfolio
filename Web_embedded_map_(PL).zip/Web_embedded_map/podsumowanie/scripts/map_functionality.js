function populateCountryFilter() {
    var countries = new Set();
    [lng_terminals, coal_terminals, powerplants].forEach(data => {
        data.features.forEach(feature => {
            var countryProperty = feature.properties.Country || feature.properties.country_lo;
            countries.add(countryProperty);
        });
    });

    var sortedCountries = Array.from(countries).sort();
    var select = document.getElementById('countryFilter');

    select.innerHTML = "";

    var defaultOption = document.createElement('option');
    defaultOption.value = "-1";
    defaultOption.text = "-SELECT-";
    defaultOption.selected = true;
    select.appendChild(defaultOption);

    sortedCountries.forEach(country => {
        var option = document.createElement('option');
        option.value = country;
        option.text = country;
        select.appendChild(option);
    });

    select.addEventListener('change', function () {
        var selectedCountry = this.value;
        if (selectedCountry !== "-1") {
            filterByCountry(selectedCountry);
        } else {
            clearLayers();
            clearInfoDisplay();
        }
    });
}

function displayCountryInfo(country) {
    var totalPowerOutput = powerplants.features
        .filter(feature => matchCountry(feature, country))
        .reduce((total, feature) => {
            var capacity = parseFloat(feature.properties.capacity_m);
            return total + (isNaN(capacity) ? 0 : capacity);
        }, 0);

    var renewablePowerOutput = powerplants.features
        .filter(feature => matchCountry(feature, country) && ['Hydro', 'Wind', 'Solar', 'Geothermal'].includes(feature.properties.primary_fu))
        .reduce((total, feature) => {
            var capacity = parseFloat(feature.properties.capacity_m);
            return total + (isNaN(capacity) ? 0 : capacity);
        }, 0);

    var nuclearPowerOutput = powerplants.features
        .filter(feature => matchCountry(feature, country) && feature.properties.primary_fu === 'Nuclear')
        .reduce((total, feature) => {
            var capacity = parseFloat(feature.properties.capacity_m);
            return total + (isNaN(capacity) ? 0 : capacity);
        }, 0);

    var lngCapacity = lng_terminals.features
        .filter(feature => matchCountry(feature, country))
        .reduce((total, feature) => {
            var capacity = parseFloat(feature.properties.Nom__Annua);
            return total + (isNaN(capacity) ? 0 : capacity);
        }, 0);

    var renewablePercentage = (renewablePowerOutput / totalPowerOutput) * 100 || 0;
    var nuclearPercentage = (nuclearPowerOutput / totalPowerOutput) * 100 || 0;

    document.getElementById('powerOutput').innerHTML = '<strong>Łączna moc elektrowni:</strong> ' + (totalPowerOutput / 1000) + ' GW';
    document.getElementById('renewablePercentage').innerHTML = '<strong>Procent energii odnawialnej:</strong> ' + renewablePercentage.toFixed(2) + '%';
    document.getElementById('nuclearPercentage').innerHTML = '<strong>Procent energii jądrowej:</strong> ' + nuclearPercentage.toFixed(2) + '%';
    document.getElementById('lngCapacity').innerHTML = '<strong>Roczna przepustowość importu LNG (droga morska):</strong> ' + lngCapacity.toFixed(2) + ' mld m³/rok';
}

function clearLayers() {
    lngLayer.clearLayers();
    coalLayer.clearLayers();
    powerplantLayer.clearLayers();
}

function clearInfoDisplay() {
    document.getElementById('powerOutput').innerHTML = '';
    document.getElementById('lngCapacity').innerHTML = '';
}

function filterByCountry(country) {

    clearLayers();

    if (document.getElementById('toggleLNG').checked) {
        lngLayer.addData(lng_terminals.features.filter(feature => matchCountry(feature, country)));
    }

    if (document.getElementById('toggleCoal').checked) {
        coalLayer.addData(coal_terminals.features.filter(feature => matchCountry(feature, country)));
    }

    if (document.getElementById('togglePowerplants').checked) {
        powerplantLayer.addData(powerplants.features.filter(feature => matchCountry(feature, country)));
    }

    displayCountryInfo(country);

    const countryCenters = {
        "Austria": { lat: 47.5162, lng: 14.5501, zoom: 6 },
        "Belgium": { lat: 50.8503, lng: 4.3517, zoom: 6 },
        "Bosnia and Herzegovina": { lat: 43.9159, lng: 17.6791, zoom: 6 },
        "Bulgaria": { lat: 42.7339, lng: 25.4858, zoom: 6 },
        "Croatia": { lat: 45.1, lng: 15.2, zoom: 6 },
        "Cyprus": { lat: 35.1264, lng: 33.4299, zoom: 6 },
        "Czech Republic": { lat: 49.8175, lng: 15.473, zoom: 6 },
        "Denmark": { lat: 56.2639, lng: 9.5018, zoom: 6 },
        "Estonia": { lat: 58.5953, lng: 25.0136, zoom: 6 },
        "Finland": { lat: 64.9241, lng: 25.7482, zoom: 4 },
        "France": { lat: 46.6034, lng: 1.8883, zoom: 5 },
        "Germany": { lat: 51.1657, lng: 10.4515, zoom: 5 },
        "Greece": { lat: 39.0742, lng: 21.8243, zoom: 6 },
        "Hungary": { lat: 47.1625, lng: 19.5033, zoom: 6 },
        "Ireland": { lat: 53.4129, lng: -8.2439, zoom: 6 },
        "Italy": { lat: 41.8719, lng: 12.5674, zoom: 5 },
        "Latvia": { lat: 56.8796, lng: 24.6032, zoom: 6 },
        "Lithuania": { lat: 55.1694, lng: 23.8813, zoom: 6 },
        "Luxembourg": { lat: 49.8153, lng: 6.1296, zoom: 6 },
        "Malta": { lat: 35.9375, lng: 14.3754, zoom: 6 },
        "Macedonia": { lat: 41.9375, lng: 19.3754, zoom: 6 },
        "Moldova": { lat: 47.4116, lng: 28.3699, zoom: 6 },
        "Montenegro": { lat: 42.7087, lng: 19.3744, zoom: 6 },
        "Netherlands": { lat: 52.1326, lng: 5.2913, zoom: 6 },
        "Norway": { lat: 64.472, lng: 8.4689, zoom: 4 },
        "Poland": { lat: 51.9194, lng: 19.1451, zoom: 6 },
        "Portugal": { lat: 39.3999, lng: -8.2245, zoom: 6 },
        "Romania": { lat: 45.9432, lng: 24.9668, zoom: 6 },
        "Slovakia": { lat: 48.669, lng: 19.699, zoom: 6 },
        "Slovenia": { lat: 46.1512, lng: 14.9955, zoom: 6 },
        "Spain": { lat: 40.4637, lng: -3.7492, zoom: 5 },
        "Sweden": { lat: 62.1282, lng: 18.6435, zoom: 4 },
        "Switzerland": { lat: 46.8182, lng: 8.2275, zoom: 6 },
        "Ukraine": { lat: 48.3794, lng: 31.1656, zoom: 5 },
        "United Kingdom": { lat: 55.3781, lng: -3.436, zoom: 5 },
    };

    if (country in countryCenters) {
        const { lat, lng, zoom } = countryCenters[country];
        map.setView([lat, lng], zoom);
    } else {
        map.setView([52.0, 10.0], 4);
    }
}

function matchCountry(feature, selectedCountry) {
    var countryProperty = feature.properties.Country || feature.properties.country_lo;
    return countryProperty === selectedCountry;
}
