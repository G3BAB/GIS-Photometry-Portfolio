function lng_color_palette(type) {
    switch (type) {
        case 'large onshore':
            return '#FF0000'; // Red
        case 'FSRU':
            return '#00FF00'; // Green
        case 'offshore GBS (Gravity Based Structure)':
            return '#0000FF'; // Blue
        case 'FRU + direct link to UGS':
            return '#FFFF00'; // Yellow
        case 'FSU + onshore regasification':
            return '#FF00FF'; // Magenta
        case 'gas port':
            return '#00FFFF'; // Cyan
        default:
            return '#117800'; // Default green
    }
}

function powerplant_color_palette(fuel) {
    switch (fuel) {
        case 'Gas':
            return '#FF5733'; // Orange
        case 'Coal':
            return '#900C3F'; // Dark red
        case 'Oil':
            return '#DAF7A6'; // Light green
        case 'Hydro':
            return '#3498DB'; // Light blue
        case 'Nuclear':
            return '#F1C40F'; // Gold
        case 'Biomass':
            return '#7D3C98'; // Purple
        case 'Wind':
            return '#5DADE2'; // Sky blue
        case 'Solar':
            return '#F39C12'; // Yellow
        case 'Geothermal':
            return '#A569BD'; // Lavender
        default:
            return '#95A5A6'; // Grey
    }
}