var coalIcon = L.icon({
    iconUrl: '../img/inverted-triangle.svg',
    iconSize: [14, 14],
    iconAnchor: [10, 10],
    popupAnchor: [0, -10]
});

function convertFeatureNames(feature) {
    const mapping = {
        "country_lo": "Państwo",
        "Country": "Państwo",
        "name": "Nazwa",
        "Name_of__i": "Nazwa",
        "Investment": "Rodzaj inwestycji",
        "Start_up_y": "Rok otwarcia",
        "Type": "Typ",
        "Terminal": "Terminal",
        "Operator": "Operator",
        "Status": "Status",
        "Operator_s": "Operator",
        "capacity_m": "Moc",
        "Capacity": "Roczna Przepustowość",
        "Nom__Annua": "Roczna przepustowość",
        "LNG_storag": "Pojemność",
        "latitude": "X",
        "Latitude": "X",
        "longitude": "Y",
        "Longitude": "Y",
        "primary_fu": "Typ",
        "commission": "Rok otwarcia",
        "owner": "Właściciel",
        "url": "URL źródła",
        "ObjectId__": null
    };

    const convertedFeature = {};
    for (const key in feature.properties) {
        if (key in mapping && mapping[key] !== null) {
            convertedFeature[mapping[key]] = feature.properties[key];
        }
    }
    return convertedFeature;
}

function generatePopupContent(properties) {
    var content = '<div>';
    const convertedProperties = convertFeatureNames({ properties });
    for (var key in convertedProperties) {
        var value = convertedProperties[key];
        if (key === 'Moc' && value === 0.0) {
            value = 'Unknown';
        }
        content += '<strong>' + key + ':</strong> ' + value + '<br>';
    }
    content += '</div>';
    return content;
}

var lngLayer = L.geoJSON(lng_terminals, {
    pointToLayer: function (feature, latlng) {
        var lng_marker_style = {
            radius: 8,
            fillColor: lng_color_palette(feature.properties.Type),
            color: "#000",
            weight: 1,
            opacity: 1,
            fillOpacity: 0.8
        };
        var marker = L.circleMarker(latlng, lng_marker_style);
        return marker;
    },
    onEachFeature: function (feature, layer) {
        layer.bindPopup(generatePopupContent(feature.properties));
    }
});

var coalLayer = L.geoJSON(coal_terminals, {
    pointToLayer: function (feature, latlng) {
        var marker = L.marker(latlng, { icon: coalIcon });
        return marker;
    },
    onEachFeature: function (feature, layer) {
        layer.bindPopup(generatePopupContent(feature.properties));
    }
});

var powerplantLayer = L.geoJSON(powerplants, {
    pointToLayer: function (feature, latlng) {
        var powerplant_marker_style = {
            radius: 4,
            fillColor: powerplant_color_palette(feature.properties.primary_fu),
            color: "#000",
            weight: 0.6,
            opacity: 0.5,
            fillOpacity: 0.6
        };
        var marker = L.circleMarker(latlng, powerplant_marker_style);
        return marker;
    },
    onEachFeature: function (feature, layer) {
        layer.bindPopup(generatePopupContent(feature.properties));
    }
});
