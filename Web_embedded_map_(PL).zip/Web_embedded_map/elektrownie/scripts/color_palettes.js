function lng_color_palette(type) {
    switch (type) {
        case 'large onshore':
            return '#FF0000'; // Red
        case 'FSRU':
            return '#00FF00'; // Green
        case 'offshore GBS (Gravity Based Structure)':
            return '#0000FF'; // Blue
        case 'FRU + direct link to UGS':
            return '#FFFF00'; // Yellow
        case 'FSU + onshore regasification':
            return '#FF00FF'; // Magenta
        case 'gas port':
            return '#00FFFF'; // Cyan
        default:
            return '#117800'; // Default green
    }
}

function powerplant_color_palette(fuel) {
    switch (fuel) {
        case 'Gas':
            return '#ff4500'; // Orange
        case 'Coal':
            return '#000000'; // Black
        case 'Oil':
            return '#854836'; // Brown
        case 'Hydro':
            return '#3498DB'; // Light blue
        case 'Nuclear':
            return '#00ff00'; // Light green
        case 'Biomass':
            return '#7D3C98'; // Dark green
        case 'Wind':
            return '#FFFFFF'; // White
        case 'Solar':
            return '#F39C12'; // Yellow
        case 'Geothermal':
            return '#ff0000'; // Lavender
        default:
            return '#95A5A6'; // Grey
    }
}