function populateCountryFilter() {
    var countries = new Set();
    [powerplants].forEach(data => {
        data.features.forEach(feature => {
            var countryProperty = feature.properties.Country || feature.properties.country_lo;
            countries.add(countryProperty);
        });
    });

    var sortedCountries = Array.from(countries).sort();
    var select = document.getElementById('countryFilter');

    select.innerHTML = "";

    var defaultOption = document.createElement('option');
    defaultOption.value = "-1";
    defaultOption.text = "-SELECT-";
    defaultOption.selected = true;
    select.appendChild(defaultOption);

    var showAllOption = document.createElement('option');
    showAllOption.value = "ALL";
    showAllOption.text = "-POKAŻ WSZYSTKIE-";
    select.appendChild(showAllOption);

    sortedCountries.forEach(country => {
        var option = document.createElement('option');
        option.value = country;
        option.text = country;
        select.appendChild(option);
    });

    select.addEventListener('change', function () {
        var selectedCountry = this.value;
        if (selectedCountry === "-1") {
            clearLayers();
            clearInfoDisplay();
        } else if (selectedCountry === "ALL") {
            showAllMarkers();
        } else {
            filterByCountry(selectedCountry);
        }
    });
}



function showAllMarkers() {
    clearLayers();
    powerplantLayer.addData(powerplants.features);
    powerplantLayer.addTo(map);
    map.setView([54.5260, 15.2551], 4);
    displayAggregatedInfo();
}

function displayAggregatedInfo() {
    var totalPowerOutput = powerplants.features.reduce((total, feature) => {
        var capacity = parseFloat(feature.properties.capacity_m);
        return total + (isNaN(capacity) ? 0 : capacity);
    }, 0);

    var renewablePowerOutput = powerplants.features.reduce((total, feature) => {
        if (['Hydro', 'Wind', 'Solar', 'Geothermal'].includes(feature.properties.primary_fu)) {
            var capacity = parseFloat(feature.properties.capacity_m);
            return total + (isNaN(capacity) ? 0 : capacity);
        }
        return total;
    }, 0);

    var nuclearPowerOutput = powerplants.features.reduce((total, feature) => {
        if (feature.properties.primary_fu === 'Nuclear') {
            var capacity = parseFloat(feature.properties.capacity_m);
            return total + (isNaN(capacity) ? 0 : capacity);
        }
        return total;
    }, 0);

    var renewablePercentage = (renewablePowerOutput / totalPowerOutput) * 100 || 0;
    var nuclearPercentage = (nuclearPowerOutput / totalPowerOutput) * 100 || 0;

    // Aggregation by fuel type
    let fuelTypeAggregates = {};

    powerplants.features.forEach(feature => {
        let fuelType = feature.properties.primary_fu;
        let capacity = parseFloat(feature.properties.capacity_m);

        if (!fuelTypeAggregates[fuelType]) {
            fuelTypeAggregates[fuelType] = { count: 0, capacity: 0 };
        }
        fuelTypeAggregates[fuelType].count += 1;
        fuelTypeAggregates[fuelType].capacity += isNaN(capacity) ? 0 : capacity;
    });

    let topPowerPlants = powerplants.features
        .sort((a, b) => parseFloat(b.properties.capacity_m) - parseFloat(a.properties.capacity_m))
        .slice(0, 5)
        .map(feature => ({
            name: feature.properties.name,
            capacity: feature.properties.capacity_m,
            type: feature.properties.primary_fu,
            year: feature.properties.commission
        }));

    document.getElementById('powerOutput').innerHTML = '<strong>Łączna moc elektrowni:</strong> ' + (totalPowerOutput / 1000) + ' GW';
    document.getElementById('renewablePercentage').innerHTML = '<strong>Procent energii odnawialnej:</strong> ' + renewablePercentage.toFixed(2) + '%';
    document.getElementById('nuclearPercentage').innerHTML = '<strong>Procent energii jądrowej:</strong> ' + nuclearPercentage.toFixed(2) + '%';

    let fuelTypeBreakdownContent = '<strong>Podział według typu paliwa:</strong><br><small>';
    for (let fuelType in fuelTypeAggregates) {
        let count = fuelTypeAggregates[fuelType].count;
        let capacity = (fuelTypeAggregates[fuelType].capacity / 1000).toFixed(2);
        fuelTypeBreakdownContent += `${fuelType}: ${count} (${capacity} GW)<br>`;
    }
    document.getElementById('fuelTypeBreakdown').innerHTML = fuelTypeBreakdownContent + '</small>';
    document.getElementById('topPowerPlants').innerHTML = '<strong>Top 5 największych elektrowni:</strong><br><small>' +
        topPowerPlants.map(plant => `${plant.name} (${plant.type}): ${(plant.capacity / 1000).toFixed(2)} GW`).join('<br>') + '</small>';
}

function filterByCountry(country) {
    clearLayers();
    powerplantLayer.addData(powerplants.features.filter(feature => matchCountry(feature, country)));
    powerplantLayer.addTo(map);
    displayCountryInfo(country);

    // Zoom definitions
    const countryCenters = {
		"Austria": { lat: 47.5162, lng: 14.5501, zoom: 6 },
        "Belgium": { lat: 50.8503, lng: 4.3517, zoom: 6 },
        "Bosnia and Herzegovina": { lat: 43.9159, lng: 17.6791, zoom: 6 },
        "Bulgaria": { lat: 42.7339, lng: 25.4858, zoom: 6 },
        "Croatia": { lat: 45.1, lng: 15.2, zoom: 6 },
        "Cyprus": { lat: 35.1264, lng: 33.4299, zoom: 6 },
        "Czech Republic": { lat: 49.8175, lng: 15.473, zoom: 6 },
        "Denmark": { lat: 56.2639, lng: 9.5018, zoom: 6 },
        "Estonia": { lat: 58.5953, lng: 25.0136, zoom: 6 },
        "Finland": { lat: 64.9241, lng: 25.7482, zoom: 4 },
        "France": { lat: 46.6034, lng: 1.8883, zoom: 5 },
        "Germany": { lat: 51.1657, lng: 10.4515, zoom: 5 },
        "Greece": { lat: 39.0742, lng: 21.8243, zoom: 6 },
        "Hungary": { lat: 47.1625, lng: 19.5033, zoom: 6 },
        "Ireland": { lat: 53.4129, lng: -8.2439, zoom: 6 },
        "Italy": { lat: 41.8719, lng: 12.5674, zoom: 5 },
        "Latvia": { lat: 56.8796, lng: 24.6032, zoom: 6 },
        "Lithuania": { lat: 55.1694, lng: 23.8813, zoom: 6 },
        "Luxembourg": { lat: 49.8153, lng: 6.1296, zoom: 6 },
        "Malta": { lat: 35.9375, lng: 14.3754, zoom: 6 },
        "Macedonia": { lat: 41.9375, lng: 19.3754, zoom: 6 },
        "Moldova": { lat: 47.4116, lng: 28.3699, zoom: 6 },
        "Montenegro": { lat: 42.7087, lng: 19.3744, zoom: 6 },
        "Netherlands": { lat: 52.1326, lng: 5.2913, zoom: 6 },
        "Norway": { lat: 64.472, lng: 8.4689, zoom: 4 },
        "Poland": { lat: 51.9194, lng: 19.1451, zoom: 6 },
        "Portugal": { lat: 39.3999, lng: -8.2245, zoom: 6 },
        "Romania": { lat: 45.9432, lng: 24.9668, zoom: 6 },
        "Slovakia": { lat: 48.669, lng: 19.699, zoom: 6 },
        "Slovenia": { lat: 46.1512, lng: 14.9955, zoom: 6 },
        "Spain": { lat: 40.4637, lng: -3.7492, zoom: 5 },
        "Sweden": { lat: 62.1282, lng: 18.6435, zoom: 4 },
        "Switzerland": { lat: 46.8182, lng: 8.2275, zoom: 6 },
        "Ukraine": { lat: 48.3794, lng: 31.1656, zoom: 5 },
        "United Kingdom": { lat: 55.3781, lng: -3.436, zoom: 5 },
    };

    // Zoom to selected country
    if (country in countryCenters) {
        const { lat, lng, zoom } = countryCenters[country];
        map.setView([lat, lng], zoom);
    } else {
        map.setView([52.0, 10.0], 4);
    }
}

function matchCountry(feature, selectedCountry) {
    var countryProperty = feature.properties.Country || feature.properties.country_lo;
    return countryProperty === selectedCountry;
}

function displayCountryInfo(country) {
    var totalPowerOutput = powerplants.features
        .filter(feature => matchCountry(feature, country))
        .reduce((total, feature) => {
            var capacity = parseFloat(feature.properties.capacity_m);
            return total + (isNaN(capacity) ? 0 : capacity);
        }, 0);

    var renewablePowerOutput = powerplants.features
        .filter(feature => matchCountry(feature, country) && ['Hydro', 'Wind', 'Solar', 'Geothermal'].includes(feature.properties.primary_fu))
        .reduce((total, feature) => {
            var capacity = parseFloat(feature.properties.capacity_m);
            return total + (isNaN(capacity) ? 0 : capacity);
        }, 0);

    var nuclearPowerOutput = powerplants.features
        .filter(feature => matchCountry(feature, country) && feature.properties.primary_fu === 'Nuclear')
        .reduce((total, feature) => {
            var capacity = parseFloat(feature.properties.capacity_m);
            return total + (isNaN(capacity) ? 0 : capacity);
        }, 0);

    var renewablePercentage = (renewablePowerOutput / totalPowerOutput) * 100 || 0;
    var nuclearPercentage = (nuclearPowerOutput / totalPowerOutput) * 100 || 0;

    // Aggregation by fuel type
    let fuelTypeAggregates = {};

    powerplants.features
        .filter(feature => matchCountry(feature, country))
        .forEach(feature => {
            let fuelType = feature.properties.primary_fu;
            let capacity = parseFloat(feature.properties.capacity_m);

            if (!fuelTypeAggregates[fuelType]) {
                fuelTypeAggregates[fuelType] = { count: 0, capacity: 0 };
            }
            fuelTypeAggregates[fuelType].count += 1;
            fuelTypeAggregates[fuelType].capacity += isNaN(capacity) ? 0 : capacity;
        });

    let topPowerPlants = powerplants.features
        .filter(feature => matchCountry(feature, country))
        .sort((a, b) => parseFloat(b.properties.capacity_m) - parseFloat(a.properties.capacity_m))
        .slice(0, 5)
        .map(feature => ({
            name: feature.properties.name,
            capacity: feature.properties.capacity_m,
            type: feature.properties.primary_fu,
            year: feature.properties.commission
        }));

    document.getElementById('powerOutput').innerHTML = '<strong>Łączna moc elektrowni:</strong> ' + (totalPowerOutput / 1000) + ' GW';
    document.getElementById('renewablePercentage').innerHTML = '<strong>Procent energii odnawialnej:</strong> ' + renewablePercentage.toFixed(2) + '%';
    document.getElementById('nuclearPercentage').innerHTML = '<strong>Procent energii jądrowej:</strong> ' + nuclearPercentage.toFixed(2) + '%';

    let fuelTypeBreakdownContent = '<strong>Podział według typu paliwa:</strong><br><small>';
    for (let fuelType in fuelTypeAggregates) {
        let count = fuelTypeAggregates[fuelType].count;
        let capacity = (fuelTypeAggregates[fuelType].capacity / 1000).toFixed(2);
        fuelTypeBreakdownContent += `${fuelType}: ${count} (${capacity} GW)<br>`;
    }
    document.getElementById('fuelTypeBreakdown').innerHTML = fuelTypeBreakdownContent + '</small>';
    document.getElementById('topPowerPlants').innerHTML = '<strong>Top 5 największych elektrowni:</strong><br><small>' +
        topPowerPlants.map(plant => `${plant.name} (${plant.type}): ${(plant.capacity / 1000).toFixed(2)} GW`).join('<br>') + '</small>';
}

function displayRankings() {
    let countryAggregates = {};

    powerplants.features.forEach(feature => {
        let country = feature.properties.Country || feature.properties.country_lo;
        let capacity = parseFloat(feature.properties.capacity_m);
        let fuelType = feature.properties.primary_fu;

        if (!countryAggregates[country]) {
            countryAggregates[country] = { total: 0, renewable: 0, nuclear: 0 };
        }
        countryAggregates[country].total += isNaN(capacity) ? 0 : capacity;
        
        if (['Hydro', 'Wind', 'Solar', 'Geothermal'].includes(fuelType)) {
            countryAggregates[country].renewable += isNaN(capacity) ? 0 : capacity;
        }

        if (fuelType === 'Nuclear') {
            countryAggregates[country].nuclear += isNaN(capacity) ? 0 : capacity;
        }
    });

    let countryTotals = [];
    let countryRenewablePercentages = [];
    let countryNuclearPercentages = [];

    for (let country in countryAggregates) {
        let totalCapacity = countryAggregates[country].total;
        let renewableCapacity = countryAggregates[country].renewable;
        let nuclearCapacity = countryAggregates[country].nuclear;

        countryTotals.push({ country: country, capacity: totalCapacity });

        if (totalCapacity > 0) {
            countryRenewablePercentages.push({
                country: country,
                percentage: (renewableCapacity / totalCapacity) * 100,
                capacity: renewableCapacity
            });

            countryNuclearPercentages.push({
                country: country,
                percentage: (nuclearCapacity / totalCapacity) * 100,
                capacity: nuclearCapacity
            });
        }
    }

    countryTotals.sort((a, b) => b.capacity - a.capacity);
    countryRenewablePercentages.sort((a, b) => b.percentage - a.percentage);
    countryNuclearPercentages.sort((a, b) => b.percentage - a.percentage);

    let topTotal = countryTotals.slice(0, 5);
    let topRenewable = countryRenewablePercentages.slice(0, 5);
    let topNuclear = countryNuclearPercentages.slice(0, 5);

    let rankingsContent = '<strong>Top 5 państw - produkcja prądu:</strong><br>';
    topTotal.forEach(item => {
        rankingsContent += `${item.country}: ${(item.capacity / 1000).toFixed(2)} GW<br>`;
    });

    rankingsContent += '<br><strong>Top 5 państw - energia odnawialna (% krajowej produkcji):</strong><br>';
    topRenewable.forEach(item => {
        rankingsContent += `${item.country}: ${item.percentage.toFixed(2)}% (${(item.capacity / 1000).toFixed(2)} GW)<br>`;
    });

    rankingsContent += '<br><strong>Top 5 państw - energia jądrowa (% krajowej produkcji):</strong><br>';
    topNuclear.forEach(item => {
        rankingsContent += `${item.country}: ${item.percentage.toFixed(2)}% (${(item.capacity / 1000).toFixed(2)} GW)<br>`;
    });

    document.getElementById('rankings').innerHTML = rankingsContent;
}
window.addEventListener('load', displayRankings);



function clearLayers() {
    powerplantLayer.clearLayers();
}

function clearInfoDisplay() {
    document.getElementById('powerOutput').innerHTML = '';
    document.getElementById('renewablePercentage').innerHTML = '';
    document.getElementById('nuclearPercentage').innerHTML = '';
    document.getElementById('fuelTypeBreakdown').innerHTML = '';
    document.getElementById('topPowerPlants').innerHTML = '';
}

var legendControl = L.Control.extend({
    options: {
        position: 'topright'
    },
    onAdd: function (map) {
        var legendDiv = L.DomUtil.create('div', 'legend');
        legendDiv.innerHTML = '<h3>Legenda</h3>' +
            '<div class="legend-elem"><span class="powerplant-marker gas"></span><span>Gas</span></div>' +
            '<div class="legend-elem"><span class="powerplant-marker coal"></span><span>Coal</span></div>' +
            '<div class="legend-elem"><span class="powerplant-marker oil"></span><span>Oil</span></div>' +
            '<div class="legend-elem"><span class="powerplant-marker hydro"></span><span>Hydro</span></div>' +
            '<div class="legend-elem"><span class="powerplant-marker nuclear"></span><span>Nuclear</span></div>' +
            '<div class="legend-elem"><span class="powerplant-marker biomass"></span><span>Biomass</span></div>' +
            '<div class="legend-elem"><span class="powerplant-marker wind"></span><span>Wind</span></div>' +
            '<div class="legend-elem"><span class="powerplant-marker solar"></span><span>Solar</span></div>' +
            '<div class="legend-elem"><span class="powerplant-marker geothermal"></span><span>Geothermal</span></div>' +
            '<small class="legend-elem">Skalowane na podstawie <br> produkcji.</small>';
        return legendDiv;
    }
});

map.addControl(new legendControl());
