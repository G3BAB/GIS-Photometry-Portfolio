function convertFeatureNames(feature) {
    const mapping = {
        "country_lo": "Państwo",
        "Country": "Państwo",
        "name": "Nazwa",
        "Name_of__i": "Nazwa",
        "Investment": "Rodzaj inwestycji",
        "Start_up_y": "Rok otwarcia",
        "Type":"Typ",
        "Terminal":"Terminal",
        "Operator":"Operator",
        "Status":"Status",
        "Operator_s": "Operator",
        "capacity_m": "Moc",
        "Capacity": "Roczna Przepustowość",
        "Nom__Annua": "Roczna przepustowość",
        "LNG_storag": "Pojemność",
        "latitude": "X",
        "Latitude": "X",
        "longitude": "Y",
        "Longitude": "Y",
        "primary_fu": "Typ",
        "commission": "Rok otwarcia",
        "owner": "Właściciel",
        "url": "URL źródła",
        "ObjectId__": null
    };

    const convertedFeature = {};
    for (const key in feature.properties) {
        if (key in mapping && mapping[key] !== null) {
            convertedFeature[mapping[key]] = feature.properties[key];
        }
    }
    return convertedFeature;
}

function generatePopupContent(properties) {
    var content = '<div>';
    const convertedProperties = convertFeatureNames({properties});
    for (var key in convertedProperties) {
        var value = convertedProperties[key];
        if (key === 'Moc' && value === 0.0) {
            value = 'Unknown';
        }
        content += '<strong>' + key + ':</strong> ' + value + '<br>';
    }
    content += '</div>';
    return content;
}

function getMinMaxCapacity() {
    let minCapacity = Infinity;
    let maxCapacity = -Infinity;

    powerplants.features.forEach(feature => {
        let capacity = parseFloat(feature.properties.capacity_m);
        if (!isNaN(capacity)) {
            if (capacity < minCapacity) minCapacity = capacity;
            if (capacity > maxCapacity) maxCapacity = capacity;
        }
    });

    return { minCapacity, maxCapacity };
}

function normalize(value, min, max) {
    return (value - min) / (max - min);
}

function scale(normalizedValue) {
    return 4 + normalizedValue * (15 - 4);
}
var { minCapacity, maxCapacity } = getMinMaxCapacity();

var powerplantLayer = L.geoJSON(powerplants, {
    pointToLayer: function (feature, latlng) {
        let capacity = parseFloat(feature.properties.capacity_m);
        let size = 4; // Default size
        if (!isNaN(capacity)) {
            let normalizedCapacity = normalize(capacity, minCapacity, maxCapacity);
            size = scale(normalizedCapacity);
        }

        var powerplant_marker_style = {
            radius: size,
            fillColor: powerplant_color_palette(feature.properties.primary_fu),
            color: "#000",
            weight: 0.6,
            opacity: 0.5,
            fillOpacity: 0.6
        };
        var marker = L.circleMarker(latlng, powerplant_marker_style);
        return marker;
    },
    onEachFeature: function (feature, layer) {
        layer.bindPopup(generatePopupContent(feature.properties));
    }
});
